ALTER TABLE presbyopia_checks
    ADD status VARCHAR(255) NULL;

ALTER TABLE sight_checks
    ADD status VARCHAR(255) NULL;