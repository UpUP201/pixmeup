ALTER TABLE eye_exercise
    MODIFY COLUMN description TEXT;