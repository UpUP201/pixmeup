ALTER TABLE sight_checks
DROP
COLUMN left_perspective;

ALTER TABLE sight_checks
DROP
COLUMN right_perspective;